<?php
/**
 * Plugin Name: Motherly Dev REST Preview
 * Plugin URI: https://mothrly.com
 * Description: Lets the Next.js dev site (localhost) load draft + published posts via a shared secret — no WordPress password in Next.js.
 * Version: 1.0.0
 * Author: Motherly
 * Requires at least: 5.8
 * Requires PHP: 7.4
 *
 * Install: WordPress → Plugins → Add New → Upload Plugin → choose motherly-dev-rest-preview.zip → Activate
 * Then edit MOTHERLY_PREVIEW_KEY below (Plugins → Plugin File Editor) to match Motherly/.env.local
 */

if (!defined('ABSPATH')) {
    exit;
}

/** Must match WORDPRESS_PREVIEW_KEY in Motherly/.env.local */
define('MOTHERLY_PREVIEW_KEY', 'motherly-dev-preview-change-this-to-a-long-random-string');

add_filter('determine_current_user', function ($user_id) {
    if (!motherly_preview_key_is_valid()) {
        return $user_id;
    }

    $users = get_users(
        array(
            'role__in' => array('administrator', 'editor', 'author'),
            'number'   => 1,
            'orderby'  => 'ID',
            'order'    => 'ASC',
        )
    );

    if (!empty($users[0]->ID)) {
        return (int) $users[0]->ID;
    }

    return $user_id;
}, 20);

/**
 * @param WP_REST_Request|null $request
 */
function motherly_preview_key_is_valid($request = null): bool
{
    if (!defined('MOTHERLY_PREVIEW_KEY') || MOTHERLY_PREVIEW_KEY === 'change-me-to-a-long-random-secret') {
        return false;
    }

    if ($request instanceof WP_REST_Request) {
        $key = $request->get_param('motherly_preview_key');
    } else {
        $key = isset($_GET['motherly_preview_key']) ? wp_unslash($_GET['motherly_preview_key']) : '';
    }

    return is_string($key) && $key !== '' && hash_equals(MOTHERLY_PREVIEW_KEY, $key);
}

add_filter('rest_post_query', function ($args, $request) {
    if (!motherly_preview_key_is_valid($request)) {
        return $args;
    }

    $args['post_status'] = array('publish', 'draft');

    return $args;
}, 10, 2);

add_action('admin_notices', function () {
    if (!current_user_can('manage_options')) {
        return;
    }
    if (motherly_preview_key_is_valid() || MOTHERLY_PREVIEW_KEY !== 'change-me-to-a-long-random-secret') {
        return;
    }
    echo '<div class="notice notice-warning"><p><strong>Motherly Dev REST Preview:</strong> Set <code>MOTHERLY_PREVIEW_KEY</code> in the plugin file to match <code>WORDPRESS_PREVIEW_KEY</code> in Next.js <code>.env.local</code>.</p></div>';
});
